from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from azure.identity import ClientSecretCredential
from azure.ai.agents import AgentsClient
from fastapi.staticfiles import StaticFiles
import uuid


from workflow import LegalRiskWorkflow
from config import *
from law_feeds import get_laws

# ========================
# APP SETUP
# ========================

app = FastAPI()
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

users = {}

# Stores last AI run for dashboard
latest_insights = {
    "categories": {},
    "countries": {},
    "laws": {}
}

# ========================
# AZURE AGENT
# ========================

credential = ClientSecretCredential(
    TENANT_ID,
    CLIENT_ID,
    CLIENT_SECRET
)

client = AgentsClient(
    endpoint=PROJECT_ENDPOINT,
    credential=credential
)

workflow = LegalRiskWorkflow(client, AGENT_ID)

# ========================
# PAGES
# ========================

@app.get("/", response_class=HTMLResponse)
async def login_page(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})

@app.get("/register", response_class=HTMLResponse)
async def register_page(request: Request):
    return templates.TemplateResponse("register.html", {"request": request})

@app.get("/home", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse("home.html", {"request": request})

@app.get("/dashboard", response_class=HTMLResponse)
async def dashboard(request: Request):
    return templates.TemplateResponse("dashboard.html", {"request": request})

@app.get("/logout", response_class=HTMLResponse)
async def logout(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})

# ========================
# AUTH
# ========================

@app.post("/login")
async def login(data: dict):
    if users.get(data["email"]) == data["password"]:
        return {"ok": True}
    return JSONResponse(status_code=401, content={"error": "invalid"})

@app.post("/register")
async def register(data: dict):
    users[data["email"]] = data["password"]
    return {"ok": True}

# ========================
# AI ANALYSIS
# ========================


RISK_WEIGHTS = {
    "fines": 15,
    "penalties": 15,
    "non-compliance": 20,
    "regulatory": 10,
    "legal": 10,
    "reputation": 10,
    "operational": 10,
    "compliance": 10
}

def compute_risk(text):
    t = text.lower()

    # Extract overall score
    score_match = re.search(r"(\d+)\s*out of\s*100", t)
    base = int(score_match.group(1)) if score_match else 60

    # Country
    countries = {
        "USA": min(100, base + 15)
    }

    # Laws detected
    laws = {}
    if "sarbanes" in t:
        laws["SOX"] = base + 10
    if "ftc" in t:
        laws["FTC"] = base + 5
    if "flsa" in t:
        laws["FLSA"] = base + 8
    if "gdpr" in t:
        laws["GDPR"] = base + 12

    # Categories from signals
    categories = {
        "Compliance": base,
        "Operational": base,
        "Reputation": base
    }

    for word, weight in RISK_WEIGHTS.items():
        if word in t:
            categories["Compliance"] = min(100, categories["Compliance"] + weight)
            categories["Operational"] = min(100, categories["Operational"] + weight // 2)

    return categories, countries, laws

@app.post("/analyze")
async def analyze_case(request: Request):
    data = await request.json()
    result = await workflow.run(data["text"])

    print("\n\nAI RESULT:\n", result, "\n\n")

    return result
# ========================
# DASHBOARD DATA
# ========================

@app.get("/insights")
async def insights():
    return latest_insights

# ========================
# LIVE LAW FEEDS
# ========================

@app.get("/laws")
async def laws():
    return await get_laws()
