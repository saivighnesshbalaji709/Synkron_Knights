import re

def clean_text(text: str) -> str:
    if not text:
        return ""

    # Remove markdown symbols
    text = text.replace("*", "")
    text = text.replace("#", "")
    text = text.replace("`", "")

    # Remove triple backticks blocks
    text = re.sub(r"```.*?```", "", text, flags=re.DOTALL)

    # Normalize whitespace
    text = re.sub(r"\n{3,}", "\n\n", text)

    return text.strip()
