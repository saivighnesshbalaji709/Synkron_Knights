import feedparser
import time
import requests

import httpx

async def get_laws():
    async with httpx.AsyncClient(timeout=5) as client:
        try:
            r = await client.get("https://newsapi.org/v2/top-headlines?q=law+regulation&apiKey=demo")
            data = r.json()
            return [a["title"] for a in data["articles"][:6]]
        except:
            return [
                "EU updates GDPR enforcement guidance",
                "United States tightens export control rules",
                "China introduces new cybersecurity compliance law",
                "India revises digital payment regulations",
                "Japan updates foreign investment review rules",
                "UK releases new data protection guidance"
            ]

