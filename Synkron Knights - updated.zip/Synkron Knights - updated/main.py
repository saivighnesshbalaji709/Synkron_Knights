import asyncio
from azure.identity import ClientSecretCredential
from azure.ai.agents import AgentsClient
from config import *
from workflow import LegalRiskWorkflow

async def main():
    credential = ClientSecretCredential(
        TENANT_ID,
        CLIENT_ID,
        CLIENT_SECRET
    )

    client = AgentsClient(
        endpoint=PROJECT_ENDPOINT,
        credential=credential
    )

    workflow = LegalRiskWorkflow(client, AGENT_ID)

    case_input = {
        "operation": "EU customer data processed by Indian vendor",
        "countries": ["Germany", "India"],
        "data": ["PII", "Sensitive"],
        "urgency": "HIGH"
    }

    result = await workflow.run(case_input)
    print(result)

if __name__ == "__main__":
    asyncio.run(main())