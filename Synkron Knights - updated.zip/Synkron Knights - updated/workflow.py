from agents import Agent
from utils import clean_text


class LegalRiskWorkflow:
    def __init__(self, client, agent_id):
        self.agent = Agent(client, agent_id)
        self.client = client

    def create_thread(self):
        return self.client.threads.create().id

    async def run(self, text):
        thread = self.create_thread()

        prompt = f"""
You are a global regulatory intelligence system speaking as an experienced compliance professional who understands how regulators actually think and enforce.

Analyze the regulatory, legal, and business implications of the provided text.

{text}

Before writing the assessment, first decide whether the input has regulatory, legal, compliance, governance, data protection, employment, financial, trade, licensing, cross-border,business or operational risk implications.

If regulatory relevance is present, proceed as follows.

Start with a short, plain-language opening of two to three sentences that directly answers the core question in human terms. This opening must clearly state whether the activity is generally allowed, restricted, or prohibited in the relevant jurisdiction, and why. Do not hedge. Do not soften conclusions. Speak like a human advisor responding verbally to a business leader.

When a national regulator has publicly stated that a practice is generally not acceptable for ordinary business use, you must reflect the regulator’s position directly and treat exceptions as rare and exceptional. Do not present restrictive regimes as “generally allowed with conditions”.

In EU employment contexts, assume employee consent is not a valid legal basis due to power imbalance unless a regulator has explicitly accepted consent for that specific use case. Do not suggest consent as a safe fallback.

The assessment must read like a clear, practical human analysis written for senior business stakeholders. Use simple, professional language. Be direct and decisive. Avoid legal jargon, boilerplate phrasing, unnecessary explanations, emojis, markdown, bullet points, numbering, or decorative formatting. Every sentence must add value.

Structure the response using the following section headings, in this exact order, with short, clear paragraphs under each heading:

Business Context and Scope
Business Potential and Positive Considerations
Regulatory and Legal Exposure
Primary Compliance and Business Risks
Avoiding Penalties and Risk Mitigation
Overall Risk Score
Final Decision and Recommendation
Comparable Real-World Cases

Under Business Potential and Positive Considerations, explain the real business motivation and operational benefit, without exaggeration or marketing language.

Under Regulatory and Legal Exposure, explain which laws or regulatory frameworks apply, name them explicitly, and explain why they apply in plain language based strictly on the provided facts.

Under Primary Compliance and Business Risks, describe concrete legal, regulatory, operational, financial, and reputational risks tied directly to the scenario. Where non-compliance is likely, clearly state realistic enforcement outcomes such as bans, orders to stop processing, fines, or mandatory system removal.

Under Avoiding Penalties and Risk Mitigation, describe practical, realistic actions a business can take. If the safest option is not to proceed or to use alternatives, state that clearly.

Under Overall Risk Score, assign a single risk score between 0 and 100 and justify it in business terms. High scores must align with restrictive recommendations.

Under Final Decision and Recommendation, state only one outcome: Approved, Conditional, or Rejected. If the activity is generally disallowed in practice, the recommendation must be Rejected or highly Conditional, not permissive.

Under Comparable Real-World Cases, reference specific regulator actions, enforcement decisions, or well-known industry examples that genuinely resemble the scenario. Avoid vague or unrelated comparisons.

Write in a natural, human advisory tone. When appropriate, begin sections with brief natural reactions such as “Hmm,” “Here’s the issue,” or “This is where companies get into trouble,” to reflect practical reasoning.

This is not a policy summary and not a consultant report. Generic compliance language is not allowed. Phrases such as “if executed correctly,” “presents an opportunity,” “significant improvements,” “competitive edge,” or “robust measures” must not appear. If they appear, the response is incorrect.

"""

        output = await self.agent.run(thread, prompt)

        return {
            "text": clean_text(output)
        }


 