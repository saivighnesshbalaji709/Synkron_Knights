from agents import Agent
from utils import clean_text


class LegalRiskWorkflow:
    def __init__(self, client, agent_id):
        self.agent = Agent(client, agent_id)
        self.client = client

    def create_thread(self):
        return self.client.threads.create().id

    async def run(self, text):
        thread = self.create_thread()

        prompt = f"""


You are a global regulatory intelligence system. Analyze the regulatory, legal, and business implications of the provided text.
{text}

The response should read like a clear, practical human assessment written for business decision-makers. Use simple, professional language. Be direct and concise. Avoid legal jargon, boilerplate phrases, and unnecessary explanations. Every sentence should add value.

Structure the response using clear section headings followed by short, easy-to-understand paragraphs. Do not use bullet points or numbering anywhere in the response.

Under Business Potential and Positive Considerations, explain the legitimate business value, efficiency, growth opportunity, or strategic benefit reflected in the scenario if executed correctly and within regulatory expectations.

Under Regulatory and Legal Exposure, clearly explain which laws or regulatory frameworks are triggered, mention the specific law names within the narrative, and explain why they apply in simple terms based only on the provided text.

Under Primary Compliance and Business Risks, describe the concrete legal, regulatory, operational, financial, and reputational risks tied directly to the scenario. Where non-compliance is possible, clearly state the penalties, fines, enforcement actions, or restrictions involved. Keep this specific to the user’s scenario and avoid generic risks.

Under Avoiding Penalties and Risk Mitigation, state the practical, real-world steps required to stay compliant and reduce risk. Focus on actions a business can realistically take.

Under Overall Risk Score, assign a single risk score between 0 and 100. Explain the score in simple business language, balancing both upside potential and downside risk.

Under Final Decision and Recommendation, provide a clear outcome of Approved, Conditional, or Rejected, with a short explanation reflecting both opportunity and risk.

Under Comparable Real-World Cases, reference specific and relevant industry or regulatory examples that closely resemble the scenario, including both successful compliant cases and enforcement actions where relevant.

The final response must be crisp, clear, balanced, scenario-specific, and written like a knowledgeable human guiding a business decision.
"""

        output = await self.agent.run(thread, prompt)

        return {
            "text": clean_text(output)
        }


 