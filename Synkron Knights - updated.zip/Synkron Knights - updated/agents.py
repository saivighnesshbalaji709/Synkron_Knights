import asyncio

class Agent:
    def __init__(self, client, agent_id):
        self.client = client
        self.agent_id = agent_id

    async def run(self, thread_id, prompt):
        self.client.messages.create(
            thread_id=thread_id,
            role="user",
            content=prompt
        )

        run = self.client.runs.create(
            thread_id=thread_id,
            agent_id=self.agent_id
        )

        while run.status in ["queued", "in_progress"]:
            await asyncio.sleep(1)
            run = self.client.runs.get(thread_id=thread_id, run_id=run.id)

        messages = list(self.client.messages.list(thread_id=thread_id))
        for msg in messages:
            if msg.role == "assistant":
                for item in msg.content:
                    if hasattr(item, "text"):
                        return item.text.value

        return "{}"